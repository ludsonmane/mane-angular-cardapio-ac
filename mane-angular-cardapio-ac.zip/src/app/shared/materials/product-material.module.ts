import { NgModule } from '@angular/core'
import { MatIconModule } from '@angular/material/icon';

@NgModule({
    imports: [],
    exports: [
        MatIconModule,
    ],
    declarations: []
})
export class ProductMaterialModule { }
