export interface LocationModel {
    id: string
    name: string
}
