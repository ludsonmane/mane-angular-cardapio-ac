export enum IconsEnum {
    Arrow = 'arrow',
    Comma = 'comma',
    Favorite = 'favorite',
    FavoriteBorder = 'favorite-border',
    Marker = 'marker',
    NoLactose = 'no-lactose',
    Options = 'options',
    Restaurant = 'restaurant',
    RestaurantBorder = 'restaurant-border',
    Search = 'search',
    Vegetarian  = 'vegetarian',
    Share = 'share',
    Info = 'info',
    Close = 'close'
}
