import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BottomNavComponent } from './bottom-nav.component';

describe('BottomNavComponent', () => {
    let component: BottomNavComponent
    let fixture: ComponentFixture<BottomNavComponent>

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [BottomNavComponent]
        })
        .compileComponents()

        fixture = TestBed.createComponent(BottomNavComponent)
        component = fixture.componentInstance
        fixture.detectChanges()
    })

    it('Deve criar o componente', () => {
        expect(component).toBeTruthy()
    })
})
