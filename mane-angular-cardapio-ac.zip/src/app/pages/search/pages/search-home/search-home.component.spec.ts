import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SearchHomeComponent } from './search-home.component';

describe('SearchHomeComponent', () => {
    let component: SearchHomeComponent
    let fixture: ComponentFixture<SearchHomeComponent>

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [SearchHomeComponent]
        })
        .compileComponents()

        fixture = TestBed.createComponent(SearchHomeComponent)
        component = fixture.componentInstance
        fixture.detectChanges()
    })

    it('Deve criar o componente', () => {
        expect(component).toBeTruthy()
    })
})
