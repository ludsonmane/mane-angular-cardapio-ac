export interface BannerCarouselModel {
    path: string
}
