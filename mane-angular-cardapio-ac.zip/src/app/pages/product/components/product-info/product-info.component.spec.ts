import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ProductInfoComponent } from './product-info.component';

describe('ProductInfoComponent', () => {
    let component: ProductInfoComponent
    let fixture: ComponentFixture<ProductInfoComponent>

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [ProductInfoComponent]
        })
        .compileComponents()

        fixture = TestBed.createComponent(ProductInfoComponent)
        component = fixture.componentInstance
        fixture.detectChanges()
    })

    it('Deve criar o componente', () => {
        expect(component).toBeTruthy()
    })
})
