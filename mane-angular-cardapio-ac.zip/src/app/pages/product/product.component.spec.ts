import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ProductComponent } from './product.component';

describe('ProductComponent', () => {
    let component: ProductComponent
    let fixture: ComponentFixture<ProductComponent>

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [ProductComponent]
        })
        .compileComponents()

        fixture = TestBed.createComponent(ProductComponent)
        component = fixture.componentInstance
        fixture.detectChanges()
    })

    it('Deve criar o componente', () => {
        expect(component).toBeTruthy()
    })
})
