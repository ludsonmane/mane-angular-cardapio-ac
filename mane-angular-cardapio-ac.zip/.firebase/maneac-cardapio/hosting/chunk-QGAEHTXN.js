import{a}from"./chunk-KB7PVN4O.js";import"./chunk-N3OUOVSN.js";import"./chunk-3XGWUAUI.js";import"./chunk-AGDBUHUE.js";import"./chunk-B3IKOZL2.js";export{a as ProductModule};
