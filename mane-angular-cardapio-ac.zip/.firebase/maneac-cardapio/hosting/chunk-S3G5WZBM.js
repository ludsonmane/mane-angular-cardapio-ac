import{a}from"./chunk-DAKSZJOA.js";import"./chunk-3XGWUAUI.js";import"./chunk-77YEWFBD.js";import"./chunk-AGDBUHUE.js";import"./chunk-B3IKOZL2.js";export{a as HomeModule};
