export const environment = {
    apiBaseUrl: 'https://cardapioac.mane.com.vc/api/',
    //apiBaseUrlbkp: 'https://mane-backend.online/api/',
    token: '55c4a1e37158e9a2d1b25fcba47b84a398e7ff7f1a09df6cd9312f6992c4ca6f2564ff9b79ff04f5f7200636b5f55f3ae2c0db2eb1c518c7ed5498a0f7be6a66ff140a0a38ea9a7ff34853a7dd1bbcec54b51f915dc1cb2c909a2347a24559338cf1d444910147a67605f1080462f279e7d1933d0b6aa4734e799a6adc388fa0'
}
