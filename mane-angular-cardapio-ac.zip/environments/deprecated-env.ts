export const environment = {
    apiBaseUrl: 'https://worthy-friend-9aefd98722.strapiapp.com/api/',
    token: 'f76cfce49b507a6fc9048d61bba93771ca63baa0aba6c179b04ab630e8c462e0ab1a7eb891703b0b9d40cc03780060202cd0717a9b2ff3d9f8160f9d14f0a8c8b1a4a37d129cc70d1da0e894e62fd616b452895ef9a48d40df21b1541b6b9dbeb9d835cd8915eb28b715ecf4d08111105c663119f530fc3ea03033e2be74f4de'
}
